How to get to pages after VM is up:

links: 
http://localhost:8080/admin/login/?next=/admin/
http://localhost:8080/polls/

Note:
I sort of forgot the password for the login site. 


New LINKS :
http://localhost:8000/
Doesnt seem to work properly though.

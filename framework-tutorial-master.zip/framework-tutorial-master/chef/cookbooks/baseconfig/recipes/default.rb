# Make sure the Apt package lists are up to date, so we're downloading versions that exist.
cookbook_file "apt-sources.list" do
  path "/etc/apt/sources.list"
end
execute 'apt_update' do
  command 'apt-get update'
end
# Base configuration recipe in Chef.
package "wget"
package "ntp"
cookbook_file "ntp.conf" do
  path "/etc/ntp.conf"
end
execute 'ntp_restart' do
  command 'service ntp restart'
end

package "ack-grep"

execute 'apt-install' do
  command 'apt-get install python-pip '
 end
 
execute 'django' do
  command 'pip install django uwsgi'
end



package 'nginx' do
  action :install
end

execute 'ntp_restart' do
  command 'service ntp restart'
end

cookbook_file "nginx-default" do
  path "/etc/nginx-default"
end

package "postgresql-server-dev-all"
package "libpython-dev"
package "python-pip"
package "postgresql"

execute 'podt' do
	command 'pip install psycopg2 uwsgi'
end

execute 'postgres_user' do
	command 'echo "CREATE DATABASE sufyan;CREATE USER ubuntu;GRANT ALL PRIVILEGES ON DATABASE sufyan TO ubuntu;"'
end

execute 'migrate' do 
	user 'ubuntu'
	cwd '/home/ubuntu/project/mysite'
	command 'python ./manage.py migrate'
end

execute 'fixture' do
	user 'ubuntu'
	cwd '/home/ubuntu/project/mysite'
	command 'python ./manage.py loaddata initial_data.json'
end

cookbook_file "rc.local" do
	path "/etc/rc.local"
end

execute 'startup' do
	command '/etc/rc.local'
end
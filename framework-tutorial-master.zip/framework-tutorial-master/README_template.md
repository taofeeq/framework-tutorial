This is the template for CMPT 470 projects, providing some basics for Vagrant and Virtualbox setups, with configuration by Chef.
